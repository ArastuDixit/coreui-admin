<footer class="footer">
    <div><a href="https://coreui.io">CoreUI </a><a href="https://coreui.io">Bootstrap Admin Template</a> © 2022 creativeLabs.</div>
    <div class="ms-auto">Powered by&nbsp;<a href="https://coreui.io/docs/">CoreUI UI Components</a></div>
</footer>
</div>
<!-- CoreUI and necessary plugins-->
<script src="coreui-bootstrap-admin/dist/vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
<script src="coreui-bootstrap-admin/dist/vendors/simplebar/js/simplebar.min.js"></script>
<!-- Plugins and scripts required by this view-->
<script src="coreui-bootstrap-admin/dist/vendors/chart.js/js/chart.min.js"></script>
<script src="coreui-bootstrap-admin/dist/vendors/@coreui/chartjs/js/coreui-chartjs.js"></script>
<script src="coreui-bootstrap-admin/dist/vendors/@coreui/utils/js/coreui-utils.js"></script>
<script src="coreui-bootstrap-admin/dist/js/main.js"></script>
<script>
</script>
<!-- Bootstrap JavaScript files -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.7.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>